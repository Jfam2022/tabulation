<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMAILS</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p>THANK YOU HAVE A GREAT DAY!!!</p>
     
    <img src="<?php echo e($message->embed('images/emailphoto.jpg')); ?>">


    
</body>
</html><?php /**PATH C:\xampp\tabulation-app\resources\views/emails/Testmail.blade.php ENDPATH**/ ?>