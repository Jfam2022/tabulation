<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Bootstrap CSS -->
     <!-- Bootstrap CSS -->
     <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/logreg.css')); ?>" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- JavaScript Bundle with Popper -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <title>Sign in and Sign Up Form</title>

<body>
<div class="containerl">

    <div class="forms-containerl">
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
      <img src="/images/LSRC.png" alt="logo of St. rose">&nbsp<h1 class="modal-title fs-5" id="exampleModalLabel">SEND YOUR PASSWORD TO YOUR GMAIL</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(route('send-email')); ?>" class="addform" method="get" >
        <?php echo csrf_field(); ?>
      <div class="modal-body">
     
            <div class="mb-3">
            
              <input type="text" class="form-control" 
              name="email" placeholder="EMAIL ACCOUNT" value="<?php echo e(old('email')); ?>"
               style="width: 290px; height:50px;" required/>
            
            </div>
           
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary btn1">SEND</button>
      </div>
    </form>
    </div>
  </div>
</div>
     <div class="signin-signup">
    
      <form action="<?php echo e(route('login-user')); ?>" class="sign-in-form" method="post">
        <?php echo csrf_field(); ?>
      <?php if(Session::has('success')): ?>
        <div class="alert alert-sucess"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('fail')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
        <?php endif; ?>
      
        <h2 class="title1">Log In</h2>
          <div class="input-field">
            <i class="bi bi-envelope-fill"></i>
            <input type="email" name="email" placeholder="Email" required>
            <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

          </div>
          <div class="input-field">
            <i class="bi bi-lock-fill"></i>
            <input type="password" name="password" placeholder="Password" required>
            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

          </div>
          <input type="submit" class="btn solid" value="Log In">
          <a href="<?php echo e(url('/')); ?>" class="buts">BACK TO HOME</a>
          <a href="#exampleModal" data-bs-toggle="modal" data-bs-target="#exampleModal" class="forgot">FORGOT PASSWORD?</a>
      </form>

      <form action="<?php echo e(route('register-user')); ?>" method="post" class="sign-up-form">
       
        <?php echo csrf_field(); ?>
          <h2 class="title">Sign Up</h2>
         
          <div class="input-field">
          <i class="bi bi-person-fill"></i>
            <input type="text" name="name" placeholder="Full Name" required/>
            <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <div class="input-field">
            <i class="bi bi-envelope-fill"></i>
            <input type="email" name="email" placeholder="Email" required/>
            <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <div class="input-field">
            <i class="bi bi-lock-fill"></i>
            <input type="password" name="password" placeholder="Password" required/>
            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <input type="submit" class="btn solid" value="Sign up">
         
          
        </form>
     </div>
    </div>

    <div class="panels-containerl">
      <div class="panel left-panel">
        <div class="content">
          <h3> New Here?</h3>
          <p> WELCOME TO  MR. AND MS ST. ROSE COLLEGE EDUCATIONAL FOUNDATION INC. TABULATION</p>
          <button class="btn transparent" id="sign-up-btn">Sign Up</button>
        </div>

        <img src="/images/LSRC.png" class="image" alt="SRC IMAGE" class="spinning">
      </div>

      <div class="panel right-panel">
        <div class="content">
           <h3> One of us?</h3>
           <p> WELCOME TO  MR. AND MS ST. ROSE COLLEGE EDUCATIONAL FOUNDATION INC. TABULATION</p>
         
            <button class="btn transparent" id="sign-in-btn">Sign In</button>
         
        </div>

        <img src="/images/LSRC.png" class="image"  alt="SRC IMAGE" class="spinning">

       </div>
    </div>
  </div>
  <script src="<?php echo e(asset('bootstrap/js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\tabulation-app\resources\views/login.blade.php ENDPATH**/ ?>