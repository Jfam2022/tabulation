<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/income.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    
   
   <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <title>INCOME INFORMATION</title>
<body>
<img class="logo" src="/images/LSRC.png" alt="ST. ROSE LOGO">
<section id="tablead">


      
     
<!-- end update modal -->
<div class="container"><br>

  <h1 ><?php echo e($req->cashier); ?></h1>
 
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
  </div>
  <?php endif; ?>
  <form class="form-floating">
  <input type="text" class="form-control " id="floatingInputValue" placeholder="CASHIER INCOME"  value="TOTAL INCOME <?php echo e($search1); ?>" readonly>

</form><br>
<div class="form-search">

<form action="<?php echo e(route('search4')); ?>" method="get">
<?php echo csrf_field(); ?>   
   <div class="input-group">
    <input type="search" name="search4" class="form-control" placeholder="SEARCH RECEIPT" > 
    <input class="form-control" type="hidden" name="cashier" value="<?php echo e($req->cashier); ?>" >
    <input class="form-control" type="hidden" name="amount" value="<?php echo e($search1); ?>" >
    <span class="input-group-prepend">&nbsp&nbsp
      <button text="submit" class="btn btn-primary">Search</button>
    </span>
   </div>
</form>
</div>


<section class="bg-ligth p-5">

  <div class="table-reponsive" id="no-more-tables">
  <table id="datatable"   class="table bg-white">
   
      <thead class="bg-dark text-light" >
        <tr align="center">
        <th > NAME</th>
          <th>USER</th>
          <th>EVENT</th>
         
          <th>RECEIPT</th>
          <th>AMOUNT </th>
          <th>POINTS </th>
          <th colspan="2">TASK</th>
        </tr>
      </thead>
      <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <?php echo csrf_field(); ?> 
      <tbody>
        <tr>
          <td  data-title=" NAME"><?php echo e($income['cashier']); ?></td>
          <td class="roles" data-title="USER"><?php echo e($income['costumer']); ?></td>
         
          <td data-title="EVENT"><?php echo e($income['events']); ?></td>
          <td  class="stats" data-title="RECEIPT"><?php echo e($income['officialr']); ?></td>
          <td  class="stats" data-title="AMOUNT"><?php echo e($income['amount']); ?></td>
          <td  class="stats" data-title="POINTS"><?php echo e($income['points']); ?></td>
        
          <td align="center"  data-title="TASK"class="task"style="width:200px;" >
           
           <a  href="<?php echo e(url('usereditincomeadmin/' .$income->id)); ?>" class="btn btn-primary">
            EDIT INCOME</a>
        
        
        </td>
        
        </td>
        </tr>
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>

<a href="<?php echo e(url('admin/')); ?>" type="button" class="btn btn-primary home">HOME</a>
<a href="<?php echo e(url('income/')); ?>" type="button" class="btn btn-primary home">BACK</a>
</section>



</div>


</div>
</div>
</section>



</body>

</html><?php /**PATH C:\xampp\tabulation-app\resources\views/admineditincome.blade.php ENDPATH**/ ?>