<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"> 
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('bootstrap/css/score.css')); ?>" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
 
    <title>ST ROSE COLLEGE EDUCATIONAL FOUNDATION INC. USER PROFILE</title>
 
    <style>  


input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button{
  -webkit-appearance:none;
  margin:0;
}




</style>

<body>
<!--header-->

<section id="header">
    <div class="header container">
           <div class="nav-bar">
            <div class="brand">
            <a href="#hero"><img src="/images/LSRC.png" alt="Logo of St. Rose"class="spinning"><a href="#hero"><h1>ST. ROSE COLLEGE EDUCATIONAL FOUNDATION INC.</h1></a>
            </div>
           <div class="nav-list">
            <div class="hamburger"><div class="bar"></div></div>
             <ul>
             <li> <a href="<?php echo e(url('judgegetcandidates/')); ?>" data-after="BACK">BACK TO CANDIDATES</a></li>
              
                <li><a href="<?php echo e(url('judgeprofile/')); ?>" data-after="HOME">HOME</a></li>

             </ul>
           </div>
        </div>
    </div>


</section><br><br>


<!-- end header-->
<!--hero--> 

 <!--user profile start-->

 <section id="container1">
 <body>
  <br><br>
  
<H2>CANDIDATE SCORE</H2>
 <div class="container1">
    <!-- femlaessssssss-->
   
    <div class="box">
    <?php if(Session::has('success')): ?>
        <div class="alert alert-sucess msg"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('fail')): ?>
        <div class="alert alert-danger msg"><?php echo e(Session::get('fail')); ?></div>
        <?php endif; ?>
      
    <form action="/savescore" method="post">
    <?php echo csrf_field(); ?>
    
    <input type="hidden" name="judge"  class="scoring" value="<?php echo e($student->Name); ?>">      
    <input type="hidden" name="gender" value="<?php echo e($data['gender']); ?>">
  
    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">

      <div class="user-details">
        
        <div class="input-box">
        <img class="imgprof" src="<?php echo e(asset('images/'.$data->image)); ?>" alt="user picture" id="output"/>
        <label><span class="label"><?php echo e($data->candino); ?></span> <?php echo e($data->namecan); ?> </label> 
            <input type="hidden" name="namecan" value="<?php echo e($data['namecan']); ?>">

       
        <br>

        <span class="details">SELECT CRITERIA</span>
        <select name="cretieria" class="form-select" aria-label="Default select example" required>
        <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
         <option value="<?php echo e($scores->creteriascores); ?>"><?php echo e($scores->creteriascores); ?></option>
         
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     </select>
     <span class="details">SCORE HERE</span>
     <input type="number" name="judgescore"  class="scoring" value="0">      
       </div>        
      </div>  
      <div class="button">   
        <input type="submit" class="btn btn-primary editbtn1" value="SAVE">
        
        </div>
    
  </form>
    </div>
<!-- end femlaessssssss asdddddddddddddddddddddddddddddd-->
<!-- start maleeeesss asdddddddddddddddddddddddddddddd-->


    <div class="table-reponsive" id="no-more-tables1">
   
<h3>YOUR SCORES</h3>
  <table id="datatable"   class="table bg-white" >
      <thead align="center" class="bg-dark text-light" >
        <tr >
        <th >CANDIDATE</th>
        <th >CRITERIA</th>
        <th >PERCENT</th>
        <th >SCORE</th>
        <th >task</th>


         
        </tr>
      </thead>
      <?php if(count($creteris) > 0): ?>
               <?php $__currentLoopData = $creteris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creteris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tbody align="center">
        <tr>
      
        <td class="CANDIDATE" data-title="CANDIDATE:"> <?php echo e($creteris['cricandidates']); ?></td>
          <td class="CRITERIA" data-title="CRITERIA"> <?php echo e($creteris['creteria']); ?></td>
          <td class="PERCENT" data-title="PERCENT"> <?php echo e($creteris['numberoption']); ?>%</td>

          <td class="SCORE" data-title="SCORE:"> <?php echo e($creteris['scores']); ?></td>
          <td align="center"  data-title="TASK" class="task"style="width:200px;" >
          <a href="<?php echo e(url('deletecri/' .$creteris['id'])); ?>"type="button" class="btn btn-danger editbtn" >CANCEL</a>&nbsp&nbsp
          </td>
    
     
        </tr>
        
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td align="center" colspan= "8">NO SUBMITTED SCORES</td>
      </tr>
      <?php endif; ?>
      
    </table>



<!-- sumbit scoressssssssssssssssssssssssssss maleeeesss asdddddddddddddddddddddddddddddd-->

    <form action="/submitscores" method="post">
    <?php echo csrf_field(); ?>
    <?php if(Session::has('success1')): ?>
        <div class="alert alert-sucess msg1"><?php echo e(Session::get('success1')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('fail1')): ?>
        <div class="alert alert-danger msg1"><?php echo e(Session::get('fail1')); ?></div>
        <?php endif; ?>
    <input type="hidden" name="judge"  class="scoring" value="<?php echo e($student->Name); ?>">      
  
    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
      <div class="user-details">
        
        <div class="input-box">
        
    <input type="hidden" name="gender" value="<?php echo e($data['gender']); ?>">
      
        <input type="hidden" name="namecno" value="<?php echo e($data['candino']); ?>">

            <input type="hidden" name="namecan" value="<?php echo e($data['namecan']); ?>">

       
        <br> 
      <div class="button">   
      <input type="submit" class="btn btn-primary editbtnsubmit" value="SUBMIT SCORES">

        
        </div>

  </form>

  </div>

   
    </div>
 
    


 </section>
 <script src="<?php echo e(asset('bootstrap/js/apps.js')); ?>"></script>

 <script>
 var loadFile = function(event){

  var output =document.getElementById('output');
  output.src = URL.createObjectURL(event.target.files[0]);
 };
</script>
</body>
</html><?php /**PATH C:\xampp\tabulation-app\resources\views/score.blade.php ENDPATH**/ ?>