<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/loading.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    
   
   <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <title>LOADING DATA</title>
<body>
<img class="logo spinning" src="/images/LSRC.png" alt="ST. ROSE LOGO">
<section id="tablead">


      
     
<!-- end update modal -->
<div class="container"><br>
  <h1 >USERS INFORMATION</h1>
 
<div class="form-search">

<form action="<?php echo e(route('search1')); ?>" method="get">
<?php echo csrf_field(); ?>   
   <div class="input-group">
    <input type="search" name="search1" class="form-control" placeholder="SEARCH EMAIL" > 
    <span class="input-group-prepend">&nbsp&nbsp
      <button text="submit" class="btn btn-primary">Search</button>
    </span>
   </div>
</form>
</div><br><br><br>
<section class="bg-ligth p-5">

  <div class="table-reponsive" id="no-more-tables">
  <table id="datatable"   class="table bg-white">
      <thead class="bg-dark text-light" >
        <tr align="center">
        <th >IMAGE</th>
          <th  >NAME</th>
          <th  >ROLE</th>
         
          <th  >EMAIL</th>
          <th  >VOTE</th>
          <th  >STATUS</th>
          <th  >TASK</th>
        </tr>
      </thead>
      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tbody>
        <tr>
        <td  data-title="IMAGE"><img class="imgprof"src="<?php echo e(asset('images/'.$Student->avatar)); ?>" alt="No Picture"></td></td>
          <td  data-title="NAME"><?php echo e($Student['Name']); ?></td>
          <td class="roles" data-title="ROLE"><?php echo e($Student['role']); ?></td>
         
          <td data-title="EMAIL"><?php echo e($Student['email']); ?></td>
          <td class="votes" data-title="VOTE"><?php echo e($Student['vote']); ?></td>
          <td  class="stats" data-title="STATUS"><?php echo e($Student['status']); ?></td>
          <td align="center"  data-title="TASK"class="task"style="width:300px;" >
           <a  href="<?php echo e(url('showload1/' .$Student->id)); ?>" class="btn btn-primary">ADD LOAD </a>
        
        
        </td>
        </tr>
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>
  <span class="tlinks">
    <?php echo e($students->links()); ?>

</span>
<br>
<a href="<?php echo e(url('loadingprofile/')); ?>" type="button" class="btn btn-primary home">HOME</a>

</section>



</div>


</div>
</div>
</section>

<script src="<?php echo e(asset('bootstrap/js/apps.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\tabulation-app\resources\views/loadingdata.blade.php ENDPATH**/ ?>