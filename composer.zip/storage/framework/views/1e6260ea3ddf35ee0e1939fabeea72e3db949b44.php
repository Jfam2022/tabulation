<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/income.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    
   
   <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <title>INFORMATION</title>
<body>
<section id="tablead">


      
     
<!-- end update modal -->
<div class="container"><br>

  <h1 >SCORING INFORMATION</h1>
 
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
  </div>
  <?php endif; ?>

<div class="form-search">

<form action="<?php echo e(route('searchtally')); ?>" method="get">
<?php echo csrf_field(); ?>   
   <div class="input-group">
   <input class="form-control" type="hidden" name="Name" value="<?php echo e($req->Name); ?>"  >

    <input type="search" name="searchtally" class="form-control" placeholder="SEARCH CANDIDATE" > 

    <span class="input-group-prepend">&nbsp&nbsp
      <button text="submit" class="btn btn-primary">Search</button>
    </span>
   </div>
</form>
</div>


<section class="bg-ligth p-5">
<h3>TOTAL SCORED: <?php echo e($creteriscount); ?></h3>
  <div class="table-reponsive" id="no-more-tables">
  <table id="datatable"   class="table bg-white">
   
      <thead class="bg-dark text-light" >
        <tr align="center">
        <th >JUDGE NAME</th>
          <th>CANDIDATE NAME</th>
          <th>OVERALL SCORE</th>
          <th>EVENT</th>
          
          <th   colspan="3"  >TASK</th>
         
      
        </tr>
      </thead>
      <?php if(count($judges) > 0): ?>
      <?php $__currentLoopData = $judges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judges): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <?php echo csrf_field(); ?> 
      <tbody>
        <tr align="center">
          <td  data-title="JUDGE NAME"><?php echo e($judges['namejudge']); ?></td>
          <td  data-title="CANDIDATE NAME"><?php echo e($judges['namecandidates']); ?></td>
         
          <td data-title="OVERALL SCORE"><?php echo e($judges['percentscores']); ?></td>
          <td class="votes" data-title="EVENT"><?php echo e($judges['overalltags']); ?></td>
          <td align="center"  data-title="TASK" class="task1" style="" >
            <a href="<?php echo e(url('showup12/' .$judges['id'])); ?>"type="button" class="btn btn-primary editbtn1" >VIEW TALLY</a>&nbsp&nbsp

        </td>
         
       
        
         
        
        </td>
        </tr>
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "3">NO SCORES SUBMITTED</td>
      </tr>
      <?php endif; ?>
    </table>
  </div>


<a href="<?php echo e(url('event/')); ?>" type="button" class="btn btn-primary home">BACK</a>
</section>



</div>


</div>
</div>
</section>



</body>

</html><?php /**PATH C:\xampp\tabulation-app\resources\views/viewjudge.blade.php ENDPATH**/ ?>