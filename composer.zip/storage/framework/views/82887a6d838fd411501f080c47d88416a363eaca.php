<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"> 
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('bootstrap/css/master.css')); ?>" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    
   
     <title>WINNERS OF PEOPLE CHOICE AND MINOR AWARDS</title>
<body>
<!--header-->

<section id="header">
    <div class="header container">
           <div class="nav-bar">
            <div class="brand">
            <a href="#hero"><img src="/images/LSRC.png" alt="Logo of St. Rose"   class="spinning"><a href="#hero"><h1>ST. ROSE COLLEGE EDUCATIONAL FOUNDATION INC.</h1></a>
            </div>
           <div class="nav-list">
            <div class="hamburger"><div class="bar"></div></div>
            <ul>
             
             <li><a href="<?php echo e(url('masterceremony/')); ?>" data-after="HOME">HOME</a></li>

                <li><a href="<?php echo e(url('logout/')); ?>" data-after="LOG OUT">LOG OUT</a></li>
             </ul>
           </div>
        </div>
    </div>


</section><br><br>


<!-- end header-->
<!--hero--> 
<section id="hero"><br><br>
<H2 style="text-align:center; color:white; margin-top:30px; margin-bottom:20px;">WINNERS INFORMATIONS</H2>

<div class="hero_container">
<div class="box1">
  <br>
<H2 style="text-align:center; color:black;">PEOPLE CHOICE </H2>
  
  <form method="post" class="join">
    <div class="user-details">
   
                <?php echo csrf_field(); ?>
          <div class="table-reponsive" id="no-more-tables">
            <table id="datatable"   class="table bg-white">
            <thead class="bg-dark text-light" >
      <tr align="center">
      <th >NAME:</th>
        <th  >CANDIDATE:</th>
        <th  >EVENT:</th>
       
        <th  >SCORE:</th>
      </tr>
      </thead>
    <?php if(count($voteswinners) > 0): ?>
    <?php $__currentLoopData = $voteswinners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voteswinner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <tbody>
      <tr>
      <td  data-title="NAME:"><?php echo e($voteswinner['votenamecan']); ?></td>
         
         <td class="CANDIDATE" data-title="CANDIDATE:"> <?php echo e($voteswinner['votecandino']); ?></td>
        
         <td class="EVENT" data-title="EVENT:"><?php echo e($voteswinner['voteeventc']); ?></td>

         <td style="color:crimson;  font-weight: 900; font-size:2rem; text-align:center;"  class="SCORE" data-title="SCORE:"><?php echo e($voteswinner['votevpointsc']); ?></td>
   
      </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
      <td colspan= "6">NO WINNERS YET</td>
    </tr>
    <?php endif; ?>
  </table>
       </div>
       </div>
   
  </form>
   
  
  
    </div>
    <div class="box">
    <br>
<H2 style="text-align:center; color:black;">MINOR AWARDS </H2>
 
    <form method="post" class="join">
    <div class="user-details">
                <?php echo csrf_field(); ?>
          <div class="table-reponsive" id="no-more-tables">
            <table id="datatable"   class="table bg-white">
            <thead class="bg-dark text-light" >
      <tr align="center">
      <th >NAME:</th>
        <th  >EVENT:</th>
        <th  >TAGS:</th>

        <th  >SCORE:</th>

       

     
      </tr>
      </thead>
    <?php if(count($minorwinners) > 0): ?>
    <?php $__currentLoopData = $minorwinners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minorwinner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <tbody>
      <tr>

      <td  data-title="NAME:"><?php echo e($minorwinner['votecurrentc']); ?></td>
         
        
         <td class="EVENT" data-title="EVENT:"><?php echo e($minorwinner['voteoptiona']); ?></td>
         <td  data-title="TAGS:"><?php echo e($minorwinner['voteoptionb']); ?></td>

         <td style="color:crimson;  font-weight: 900; font-size:2rem; text-align:center;"  class="SCORE" data-title="SCORE:"><?php echo e($minorwinner['votevscores']); ?></td>
   
      </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
      <td colspan= "6">NO WINNERS YET</td>
    </tr>
    <?php endif; ?>
  </table>
       </div>
       </div>
     
</form>
   
  
  
    </div>
   
 </div>
</div>
 </section>
 <!--user profile start-->


 
 <script src="<?php echo e(asset('bootstrap/js/apps.js')); ?>"></script>

 <script>
 var loadFile = function(event){

  var output =document.getElementById('output');
  output.src = URL.createObjectURL(event.target.files[0]);
 };
</script>
</body>
</html><?php /**PATH C:\xampp\tabulation-app\resources\views/masterceremonyminors.blade.php ENDPATH**/ ?>