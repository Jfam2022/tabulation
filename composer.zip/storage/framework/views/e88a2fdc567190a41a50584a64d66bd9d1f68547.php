<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/income.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    
   
   <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <title>INCOME</title>
<body>
<img class="logo" src="/images/LSRC.png" alt="ST. ROSE LOGO">
<section id="tablead">


      
     
<!-- end update modal -->
<div class="container"><br>

  <h1 >INCOME DATABASE</h1>
  <form class="form-floating">
  <input type="text" class="form-control " id="floatingInputValue" placeholder="CASHIER INCOME"  value="CURRENT INCOME <?php echo e($totalincome); ?> pesos" readonly>
 
</form><br>
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
  </div>
  <?php endif; ?>
<div class="form-search">

<form action="<?php echo e(route('search2')); ?>" method="get">
<?php echo csrf_field(); ?>   
   <div class="input-group">
    <input type="search" name="search2" class="form-control" placeholder="SEARCH CASHIER NAME" > 
    <span class="input-group-prepend">&nbsp&nbsp
      <button text="submit" class="btn btn-primary">Search</button>
    </span>
   </div>
</form>
</div>
<section class="bg-ligth p-5">

  <div class="table-reponsive" id="no-more-tables">
  <table id="datatable"   class="table bg-white">
      <thead class=" text-light" >
        <tr align="center">
        <th >CASHIER NAME</th>
          <th>COSTUMER</th>
          <th>EVENT</th>
          <th>YEAR</th>
         
          <th>RECEIPT</th>
          <th>AMOUNT </th>
          <th>POINTS </th>
          <th colspan="2">TASK</th>
        </tr>
      </thead>
      <?php if(count($incomes) > 0): ?>
      <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tbody>
        <tr>
          <td  data-title="CASHIER NAME"><?php echo e($income['cashier']); ?></td>
          <td class="roles" data-title="COSTUMER"><?php echo e($income['costumer']); ?></td>
         
          <td data-title="EVENT"><?php echo e($income['events']); ?></td>
          <td class="votes" data-title="YEAR"><?php echo e($income['date']); ?></td>
          <td  class="stats" data-title="RECEIPT"><?php echo e($income['officialr']); ?></td>
          <td  class="stats" data-title="AMOUNT"><?php echo e($income['amount']); ?></td>
          <td  class="stats" data-title="POINTS"><?php echo e($income['points']); ?></td>
          <td align="center"  data-title="TASK"class="task"style="width:200px;" >
           
           <a  href="<?php echo e(url('admineditincome/' .$income->cashier)); ?>" class="btn btn-primary">SHOW INCOME </a>
        
        
        </td>
        </tr>
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "7">NO CUSTOMER</td>
      </tr>
      <?php endif; ?>
        </table>
       </div> 
 
  <span class="tlinks">
    <?php echo e($incomes->links()); ?>

</span>
<a href="<?php echo e(url('admin/')); ?>" type="button" class="btn btn-primary home">HOME</a>

</section>



</div>


</div>
</div>
</section>

<script src="<?php echo e(asset('bootstrap/js/apps.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\tabulation-app\resources\views/adminincome.blade.php ENDPATH**/ ?>