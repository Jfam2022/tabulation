<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/getwinner.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
   <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<title>GET WINNERS</title>



<body>
 
<section id="header">
    <div class="header container1">
           <div class="nav-bar">
            <div class="brand">
            <a href="#hero"><img src="/images/LSRC.png" alt="logo of St. rose"><a href="#hero"><h1>ST. ROSE COLLEGE <span >EDUCATIONAL</span> FOUNDATION INC.</h1></a>
            </div>
           <div class="nav-list">
            <div class="hamburger"><div class="bar"></div></div>
             <ul>
             
                <li><a href="<?php echo e(url('event/')); ?>" data-after="EVENT">BACK TO EVENT</a></li>

                <li><a href="<?php echo e(url('admin/')); ?>" data-after="HOME">HOME</a></li>
             </ul>
           </div>
        </div>
    </div>
   

</section> 
<section id="tablead">
<br><br><br><br>

<!-- start add modal -->
<br><br><br>
<h1 >WINNERS INFORMATION</i></h1>


 <div class="container">

 
    <div class="box">
    <?php if(Session::has('success')): ?>
             <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
             <?php endif; ?>
             <?php if(Session::has('fail')): ?>
             <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
             <?php endif; ?>   
      <?php echo csrf_field(); ?>
        <div class="title">FEMALE CANDIDATES</div>
            <form method="post" class="join">
                <?php echo csrf_field(); ?>
                <div class="user-details">
    <section class="bg-ligth p-5">

        <div class="box">

          <div class="table-reponsive" id="no-more-tables">
            <table id="datatable"   class="table bg-white">
            
              <?php if(count($females) > 0): ?>
               <?php $__currentLoopData = $females; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $female): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tbody>
                <tr> <td align="center"  data-title="IMAGE"><img class="imgprof"src="<?php echo e(asset('images/'.$female->image)); ?>" alt="candidate Picture"></td></td>
      
        <td  data-title="NAME:"><?php echo e($female['namecan']); ?></td>
         
          <td class="CANDIDATE" data-title="CANDIDATE:"> <?php echo e($female['candino']); ?></td>
         
          <td class="EVENT" data-title="EVENT:"><?php echo e($female['eventc']); ?></td>
          <td class="TAGS" data-title="TAGS:"><?php echo e($female['optionb']); ?></td>

          <td style="color:crimson;  font-weight: 900; font-size:2rem;"  class="SCORE" data-title="SCORE:"><?php echo e($female['vscores']); ?></td>
          <td align="center"  data-title="TASK" class="task1" style="" >
            <a href="<?php echo e(url('updatetop/' .$female['id'])); ?>"type="button" class="btn btn-primary editbtn1" >GET TOP 5</a>&nbsp&nbsp
            <a href="<?php echo e(url('updatewinners/' .$female['id'])); ?>" type="button" class="btn btn-primary editbtn1" >GET TOP 3</a>&nbsp&nbsp
          
        
        
        </td>
        </tr>
        </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "3">NO CANDIDATES</td>
      </tr>
      <?php endif; ?>

     

      <?php if(count($voteswinnerFs) > 0): ?>
               <?php $__currentLoopData = $voteswinnerFs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voteswinnerF): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tbody>
                <tr>
        <td  data-title="NAME:"><?php echo e($voteswinnerF['namecan']); ?></td>
         
          <td class="CANDIDATE" data-title="CANDIDATE:"> <?php echo e($voteswinnerF['candino']); ?></td>
         
          <td class="EVENT" data-title="EVENT:"><?php echo e($voteswinnerF['eventc']); ?></td>

          <td style="color:crimson;  font-weight: 900; font-size:2rem;"  class="TAGS" data-title="TAGS:"><?php echo e($voteswinnerF['currentc']); ?></td>
        
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "3">NO VOTE WINNER YET</td>
      </tr>
      <?php endif; ?>
        </table>
        </table>
       </div>

    </section>

   
   
 
                </div>
 
            </form>
    </div>
<!-- end join asdddddddddddddddddddddddddddddd-->
<!-- start mr and ms asdddddddddddddddddddddddddddddd-->



<!-- end update modal asdddddddddddddddddddddddddddddd-->

    <div class="box">
        <div class="title">MALE CANDIDATES</div>
            <form enctype='multipart/form-data' action="" method="post" class="form-container">
 
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PUT'); ?>
                <div class="user-details">
                <section class="bg-ligth p-5">

<div class="box">

  <div class="table-reponsive" id="no-more-tables">
  <table id="datatable"   class="table bg-white">
      <thead class="bg-dark text-light" >
     
      <?php if(count($males) > 0): ?>
      <?php $__currentLoopData = $males; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $male): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tbody>
        <tr>
        <td align="center"  data-title="IMAGE"><img class="imgprof"src="<?php echo e(asset('images/'.$male->image)); ?>" alt="candidate Picture"></td></td>
      
        <td  data-title="NAME:"><?php echo e($male['namecan']); ?></td>
         
          <td class="CANDIDATE" data-title="CANDIDATE:"> <?php echo e($male['candino']); ?></td>
         
          <td class="EVENT" data-title="EVENT:"><?php echo e($male['eventc']); ?></td>
          <td class="TAGS" data-title="TAGS:"><?php echo e($male['optionb']); ?></td>

          <td style="color:crimson;  font-weight: 900; font-size:2rem;" class="SCORE" data-title="SCORE:"><?php echo e($male['vscores']); ?></td>
          <td align="center"  data-title="TASK" class="task1" style=" margin:10px" >
            <a href="<?php echo e(url('updatetop/' .$male['id'])); ?>" type="button" class="btn btn-primary editbtn1" >GET TOP 5</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
           <a href="<?php echo e(url('updatewinners/' .$male['id'])); ?>" type="button" class="btn btn-primary editbtn1" >GET TOP 3</a>&nbsp&nbsp
          
        
        </td>
        </tr>
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "3">NO CANDIDATES</td>
      </tr>
      <?php endif; ?>

     

      <?php if(count($voteswinnerMs) > 0): ?>
               <?php $__currentLoopData = $voteswinnerMs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voteswinnerMs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tbody>
                <tr>
        <td  data-title="NAME:"><?php echo e($voteswinnerMs['namecan']); ?></td>
         
          <td class="CANDIDATE" data-title="CANDIDATE:"> <?php echo e($voteswinnerMs['candino']); ?></td>
         
          <td class="EVENT" data-title="EVENT:"><?php echo e($voteswinnerMs['eventc']); ?></td>
          <td style="color:crimson;  font-weight: 900; font-size:2rem;"  class="TAGS" data-title="TAGS:"><?php echo e($voteswinnerMs['currentc']); ?></td>
        
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "3">NO VOTE WINNER YET</td>
      </tr>
      <?php endif; ?>
    </table>
  </div>

                </div>
     
</form>
 
    

</div>
</div>
</section> 

<script src="<?php echo e(asset('bootstrap/js/apps.js')); ?>"></script>
<script>
 var loadFile5 = function(event){

  var output5 =document.getElementById('output5');
  output5.src = URL.createObjectURL(event.target.files[0]);
 };
</script>
</body>

</html> <?php /**PATH C:\xampp\tabulation-app\resources\views/getwinner.blade.php ENDPATH**/ ?>