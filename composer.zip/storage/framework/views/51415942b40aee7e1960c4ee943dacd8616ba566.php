<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/income.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- Bootstrap Bundle with Popper -->
    
   
   <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <title>SCORING</title>
<body>
<section id="tablead">


      
     
<!-- end update modal -->
<div class="container"><br>

  <h1 > <?php echo e($data->namecandidates); ?> SCORING</h1>
 
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
  </div>
  <?php endif; ?>




<section class="bg-ligth p-5">

  <div class="table-reponsive" id="no-more-tables">
  <table id="datatable"   class="table bg-white">
   
      <thead class="bg-dark text-light" >
        <tr align="center">
        <th >JUDGE NAME</th>
          <th>CANDIDATE NAME</th>
          <th>CRITERIA</th>
          <th>SCORE</th>
          <th>EVENT</th>
          
       
         
      
        </tr>
      </thead>
      <?php if(count($creteris) > 0): ?>
      <?php $__currentLoopData = $creteris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creteris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <?php echo csrf_field(); ?> 
      <tbody>
        <tr align="center">
          <td  data-title="JUDGE NAME"><?php echo e($creteris['judgename']); ?></td>
          <td  data-title="CANDIDATE NAME"><?php echo e($creteris['cricandidates']); ?></td>
          <td  data-title="CRETERIA"><?php echo e($creteris['creteria']); ?></td>
          <td data-title="SCORE"><?php echo e($creteris['scores']); ?></td>
          <td class="votes" data-title="EVENT"><?php echo e($creteris['crievent']); ?></td>
      
         
       
        
         
      
        </tr>
      </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
        <td  colspan= "3">NO SCORES SUBMITTED</td>
      </tr>
      <?php endif; ?>
    </table>
  </div>


<a href="<?php echo e(url('event/')); ?>" type="button" class="btn btn-primary home">BACK</a>
</section>



</div>


</div>
</div>

</section>



</body>

</html><?php /**PATH C:\xampp\tabulation-app\resources\views/viewtally.blade.php ENDPATH**/ ?>